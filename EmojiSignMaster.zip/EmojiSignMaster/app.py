import os
import random
from flask import Flask, render_template, jsonify, request, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "asl_game_secret_key"
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///game.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
db.init_app(app)

# ASL sign data with corresponding emojis
ASL_SIGNS = [
    {"word": "all done", "image": "/attached_assets/image_1735148381708.png", "emoji": "✅🙌", "choices": ["🍽🍕", "✅🙌", "🚫❌", "🛑🚦"]},
    {"word": "don't", "image": "/attached_assets/image_1735148384803.png", "emoji": "🚫✋", "choices": ["🚫✋", "🍔🍟", "✅🙌", "📚📖"]},
    {"word": "eat", "image": "/attached_assets/image_1735148387967.png", "emoji": "🍽🍴", "choices": ["🕹🎮", "💧🚰", "🍽🍴", "🧸🐻"]},
    {"word": "friends", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.24.20_7b5da825_1735149256162.jpg", "emoji": "🧑‍🤝‍🧑👭", "choices": ["🚽🚻", "🧑‍🤝‍🧑👭", "🎮⚽", "🤕"]},
    {"word": "help", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.24.59_fbc401cb_1735149260149.jpg", "emoji": "🆘🤝", "choices": ["🛏🛌", "🌊🏞", "🆘🤝", "🐕🐾"]},
    {"word": "hello", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.36.19_50208232_1735149263766.jpg", "emoji": "👋😊", "choices": ["⏰📅", "👋😊", "🐈😺", "🚦🛑"]},
    {"word": "hungry", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.36.50_bc04ba81_1735149267098.jpg", "emoji": "🤤🍔", "choices": ["🐻🧸", "✅❤", "🤤🍔", "🛏😴"]},
    {"word": "like", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.37.23_effc76d3_1735149271609.jpg", "emoji": "👍❤", "choices": ["🐻🧸", "👍❤", "🤤🍔", "🛏😴"]},
    {"word": "me", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.37.47_424f6954_1735149275892.jpg", "emoji": "🙋‍♀🙋‍♂", "choices": ["🚫✋", "🙋‍♀🙋‍♂", "🧃🥛", "🎲🕹"]},
    {"word": "more", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.38.20_9ca6162b_1735149279535.jpg", "emoji": "➕🔼", "choices": ["📚📖", "🥣🍓", "➕🔼", "🚦⛔"]},
    {"word": "no", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.38.51_3f82da6c_1735149283451.jpg", "emoji": "🚫❌", "choices": ["🍏🍎", "🚫❌", "✅👍", "🕹🎮"]},
    {"word": "play", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.39.31_8594e352_1735149290033.jpg", "emoji": "🎮⚽", "choices": ["🎮⚽", "🤤🍕", "🛏😴", "🐱🐈"]},
    {"word": "please", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.39.58_5ebacdba_1735149293536.jpg", "emoji": "🙏😊", "choices": ["🙏😊", "🚽🚻", "💧🚰", "🐻🧸"]},
    {"word": "stop", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.40.27_d5ec5341_1735149297016.jpg", "emoji": "🛑✋", "choices": ["🛑✋", "🤔❓", "🚽🚾", "📖📚"]},
    {"word": "thank you", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.41.01_c37451f3_1735149301364.jpg", "emoji": "🙏😊", "choices": ["🎮🕹", "🚫✋", "🐕🐶", "🙏😊"]},
    {"word": "toilet", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.41.36_b4341a86_1735149305522.jpg", "emoji": "🚽🚻", "choices": ["🚽🚻", "🤤🍔", "🎭🎬", "🕰⏳"]},
    {"word": "want", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.42.07_3074dc63_1735149308956.jpg", "emoji": "🤲✨", "choices": ["🐈‍⬛🐕", "🤲✨", "🚽🚾", "✅🚫"]},
    {"word": "water", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.43.02_c2bfd6ad_1735149316848.jpg", "emoji": "💧🚰", "choices": ["💧🚰", "🎲📚", "🧸🐻", "🐱🐈"]},
    {"word": "what", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.43.30_a20d5a04_1735149322315.jpg", "emoji": "❓🤔", "choices": ["❓🤔", "🛌🛏", "🚫❌", "🎮⚽"]},
    {"word": "when", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.44.11_7f19a74f_1735149345632.jpg", "emoji": "⏰📅", "choices": ["⏰📅", "🤤🍕", "🐕🐾", "🚽🛁"]},
    {"word": "where", "image": "/attached_assets/WhatsApp Image 2024-12-17 at 18.44.40_d70e36f7_1735149356322.jpg", "emoji": "📍🗺", "choices": ["🙌✅", "📍🗺", "🧸🐻", "🚽🚻"]},
    {"word": "who", "image": "/attached_assets/image_1735149047243.png", "emoji": "🕵‍♂❓", "choices": ["🕵‍♂❓", "🍔🍟", "🚦🛑", "🚫🛑"]},
    {"word": "why", "image": "/attached_assets/image_1735149055163.png", "emoji": "🤷‍♀🤷‍♂", "choices": ["🧃🥛", "🤷‍♀🤷‍♂", "🎮⚽", "🍴🥣"]},
    {"word": "yes", "image": "/attached_assets/image_1735149057571.png", "emoji": "✅👍", "choices": ["✅👍", "🚽🚻", "🐕🐾", "🚫🛑"]},
    {"word": "you", "image": "/attached_assets/image_1735149059699.png", "emoji": "👉😊", "choices": ["🎭🎬", "🚫✋", "👉😊", "🐈🐱"]}
]

@app.route('/')
def index():
    return render_template('game.html')

@app.route('/api/sign')
def get_sign():
    sign = random.choice(ASL_SIGNS)
    return jsonify({
        "sign": {
            "word": sign["word"],
            "image": sign["image"],
            "emoji": sign["emoji"],
            "meaning": sign["word"]
        },
        "choices": sign["choices"]
    })

@app.route('/attached_assets/<path:filename>')
def serve_attached_assets(filename):
    return send_from_directory('attached_assets', filename)

with app.app_context():
    import models
    db.create_all()

    # Initialize database with signs if empty
    if models.Sign.query.count() == 0:
        for sign in ASL_SIGNS:
            new_sign = models.Sign(
                word=sign["word"],
                image_path=sign["image"],
                correct_emoji=sign["emoji"],
                choices=sign["choices"]
            )
            db.session.add(new_sign)
        db.session.commit()