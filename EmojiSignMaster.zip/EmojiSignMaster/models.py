from app import db
from datetime import datetime

class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    points = db.Column(db.Integer, default=0)
    timestamp = db.Column(db.DateTime, server_default=db.func.now())
    current_streak = db.Column(db.Integer, default=0)
    highest_streak = db.Column(db.Integer, default=0)
    badges = db.Column(db.JSON, default=list)  # Store earned badges

class Sign(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    word = db.Column(db.String(50), nullable=False)
    image_path = db.Column(db.String(255), nullable=False)
    correct_emoji = db.Column(db.String(20), nullable=False)
    choices = db.Column(db.JSON, nullable=False)  # Store emoji choices as JSON array
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class UserProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signs_completed = db.Column(db.Integer, default=0)
    current_streak = db.Column(db.Integer, default=0)
    highest_streak = db.Column(db.Integer, default=0)
    badges_earned = db.Column(db.JSON, default=list)  # ['5_streak', '10_streak', '20_streak', '50_streak']
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)