class ASLGame {
    constructor() {
        this.score = 0;
        this.currentStreak = 0;
        this.highestStreak = 0;
        this.signsCompleted = 0;
        this.totalSigns = 25;
        this.currentSign = null;
        this.isLoading = false;
        this.init();
    }

    init() {
        this.scoreElement = document.getElementById('score');
        this.signImage = document.getElementById('asl-sign');
        this.choicesContainer = document.getElementById('choices-container');
        this.feedbackElement = document.getElementById('feedback');
        this.streakElement = document.getElementById('current-streak');
        this.highestStreakElement = document.getElementById('highest-streak');
        this.progressBar = document.getElementById('progress-bar');
        this.badgesContainer = document.getElementById('badges');

        // Initialize buttons
        document.getElementById('next-button').addEventListener('click', () => {
            if (!this.isLoading) {
                this.loadNewSign();
            }
        });
        document.getElementById('reset-button').addEventListener('click', () => {
            if (!this.isLoading) {
                this.resetGame();
            }
        });

        this.loadNewSign();
        this.updateProgress();
    }

    async loadNewSign() {
        if (this.isLoading) return;

        this.isLoading = true;
        this.disableChoices();
        this.hideFeedback();

        try {
            const response = await fetch('/api/sign');
            const data = await response.json();

            // Add a small delay before showing the new sign
            await new Promise(resolve => setTimeout(resolve, 500));

            this.currentSign = data.sign;
            this.signImage.src = this.currentSign.image;
            this.signImage.alt = `ASL sign for ${this.currentSign.word}`;

            this.renderChoices(data.choices);
            this.enableChoices();
        } catch (error) {
            console.error('Error loading sign:', error);
            this.showFeedback('Error loading sign. Please try again.', 'error');
        } finally {
            this.isLoading = false;
        }
    }

    renderChoices(choices) {
        this.choicesContainer.innerHTML = '';

        choices.forEach(emoji => {
            const choiceDiv = document.createElement('div');
            choiceDiv.className = 'col-6 col-md-3 text-center mb-3';

            const button = document.createElement('button');
            button.className = 'emoji-choice btn btn-light btn-lg';
            button.textContent = emoji;
            button.setAttribute('aria-label', `Select emoji ${emoji}`);

            button.addEventListener('click', () => {
                if (!this.isLoading) {
                    this.checkAnswer(emoji);
                }
            });

            choiceDiv.appendChild(button);
            this.choicesContainer.appendChild(choiceDiv);
        });
    }

    async checkAnswer(selectedEmoji) {
        if (this.isLoading) return;

        this.isLoading = true;
        this.disableChoices();

        const isCorrect = selectedEmoji === this.currentSign.emoji;

        if (isCorrect) {
            this.score += 10;
            this.currentStreak++;
            this.signsCompleted++;
            this.highestStreak = Math.max(this.currentStreak, this.highestStreak);
            this.showFeedback(`Correct! 🎉 The sign means "${this.currentSign.word}"`, 'success');
            this.checkBadges();
        } else {
            this.currentStreak = 0;
            this.showFeedback(`Wrong! The correct answer was ${this.currentSign.emoji} for "${this.currentSign.word}"`, 'error');
        }

        this.updateUI();

        // Add a delay before loading the next sign
        await new Promise(resolve => setTimeout(resolve, 2000));
        this.isLoading = false;
        this.loadNewSign();
    }

    updateUI() {
        this.scoreElement.textContent = this.score;
        this.streakElement.textContent = this.currentStreak;
        this.highestStreakElement.textContent = this.highestStreak;
        this.updateProgress();
    }

    updateProgress() {
        const progress = (this.signsCompleted / this.totalSigns) * 100;
        this.progressBar.style.width = `${progress}%`;
        this.progressBar.setAttribute('aria-valuenow', progress);
    }

    checkBadges() {
        const streakBadges = [
            { streak: 5, id: '5_streak', emoji: '🥉' },
            { streak: 10, id: '10_streak', emoji: '🥈' },
            { streak: 20, id: '20_streak', emoji: '🥇' },
            { streak: 50, id: '50_streak', emoji: '👑' }
        ];

        streakBadges.forEach(badge => {
            if (this.currentStreak === badge.streak) {
                this.awardBadge(badge);
            }
        });
    }

    awardBadge(badge) {
        if (!this.badgesContainer.querySelector(`[data-badge="${badge.id}"]`)) {
            const badgeElement = document.createElement('div');
            badgeElement.className = 'badge bg-warning text-dark p-2';
            badgeElement.setAttribute('data-badge', badge.id);
            badgeElement.textContent = `${badge.emoji} ${badge.streak}`;
            this.badgesContainer.appendChild(badgeElement);

            this.showFeedback(`Congratulations! You earned a ${badge.streak} streak badge! ${badge.emoji}`, 'success');
        }
    }

    resetGame() {
        if (this.isLoading) return;

        this.score = 0;
        this.currentStreak = 0;
        this.signsCompleted = 0;
        this.badgesContainer.innerHTML = '';
        this.updateUI();
        this.loadNewSign();
    }

    disableChoices() {
        const choices = document.querySelectorAll('.emoji-choice');
        choices.forEach(choice => choice.disabled = true);
    }

    enableChoices() {
        const choices = document.querySelectorAll('.emoji-choice');
        choices.forEach(choice => choice.disabled = false);
    }

    showFeedback(message, type) {
        this.feedbackElement.textContent = message;
        this.feedbackElement.className = `feedback-message feedback-${type} alert ${type === 'success' ? 'alert-success' : 'alert-danger'}`;
        this.feedbackElement.style.opacity = '1';
    }

    hideFeedback() {
        this.feedbackElement.style.opacity = '0';
    }
}

// Start the game when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new ASLGame();
});